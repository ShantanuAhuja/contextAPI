import React, { useContext } from 'react'
import { FirstName, LastName } from './App';

const CompD = () => {
	const fname = useContext(FirstName);
	const lname = useContext(LastName);
	return (
		<>
			<FirstName.Consumer>{(name) => {
				//CONSUMER can be called by a call back function which takes a parameter and the value of the paramter is value declared by provider in app.jsx
				return <h1>My Name is {fname} {lname}</h1>;

			}}</FirstName.Consumer>

		</>
	);
};
export default CompD;
