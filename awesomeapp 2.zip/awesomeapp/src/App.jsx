import React, { createContext } from 'react'

import CompA from './CompA'
// provider declares the value which shoould by changed in CompD and we can access CompD with the help of context API
//target is to change the first name shantanu from app file in CompD file
const FirstName = createContext();
const App = () => {
    return (
        <>

            <FirstName.Provider value={"Shantanu"}>


                <CompA />
            </FirstName.Provider>

        </>
    );
};
export default App;
export { FirstName };
