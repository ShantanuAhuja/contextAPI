import React from 'react'
import { FirstName } from './App';

const CompD = () => {
	return (
		<>
			<FirstName.Consumer>{(name) => {
				return <h1>My Name is {name} Ahuja</h1>;

			}}</FirstName.Consumer>

		</>
	);
};
export default CompD;
