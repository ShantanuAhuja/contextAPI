import React from 'react'
import CompC from './CompC'
const CompB = () => {
	return (
		<>
			<CompC />
		</>
	);
};
export default CompB;
