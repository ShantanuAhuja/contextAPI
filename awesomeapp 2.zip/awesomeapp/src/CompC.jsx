import React from 'react'
import CompD from './CompD'
const CompC = () => {
	return (
		<>
			<CompD />
		</>
	);
};
export default CompC;
