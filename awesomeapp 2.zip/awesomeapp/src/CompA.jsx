import React from 'react'
import CompB from './CompB'
const CompA = () => {
	return (
		<>
			<CompB />
		</>
	);
};
export default CompA;
